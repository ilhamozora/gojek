# Auto Register Gojek, Claim Voucher Gofood + Goride

Bahan : Termux, 2ndline, texnow dll

apabila sebelum nya sudah git clone di termux ketik rm -rf boba7 kemudian git clone ulang

pkg install git

pkg install php

git clone https://github.com/ilhamozora/gojek

cd boba7

php up.php

No HP mu : contoh (609) 483-4013

Auto Recaple to +16094834013

Kode OTP : otp di sms nanti

Claim GoFood, GoRide, Send Gopay Rp 1 - 10 acak
